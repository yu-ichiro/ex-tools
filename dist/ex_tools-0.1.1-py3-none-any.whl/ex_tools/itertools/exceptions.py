class NotFound(Exception):
    """
    Exception that is raised when ex_tools.itertools.find can't find any element
    """
    pass
